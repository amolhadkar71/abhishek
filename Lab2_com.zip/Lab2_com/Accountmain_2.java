package Lab2_com;

public class Accountmain_2 {

	public static void main(String args[])
	{
		Person p1=new Person("Dhoni",35);
		Account a1=new Account(2000,p1);
		Person p2=new Person("Sachin",35);
		Account a2=new Account(3000,p2);
		SavingsAccount s1=new SavingsAccount(3000,p1);
		CurrentAccount c1=new CurrentAccount(4000,p2);
		a1.deposit(2000);
		a2.withdraw(2000);
		a1.print();
		a2.print();
		s1.withdraw(2000);
		s1.print();
		c1.withdraw(2000);
		c1.print();
	}

		
	}
	

package Lab2_com;

	public class SavingsAccount extends Account{
			
		
		public static final double miniBalance=1000;
		public SavingsAccount() {
			
		}
		public SavingsAccount(double balance, Person accHolder) {
			super();
			this.balance=balance;
			this.accHolder=accHolder;
		}
		public void withdrawn(double amt) {
			if((amt>=balance)&&(amt>=miniBalance)) {
				balance=balance-amt;
			}
			else
			{
				System.out.println("Balnce is insufficient or mini balance reached");
			}
		}
		public void print() {
			System.out.println(this);
		}
		public String toString() {
			return accHolder.toString()+"\nAccount Number:" + accNum+ "\nBalance:" + getBalance();
		}
}





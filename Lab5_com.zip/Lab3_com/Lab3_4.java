package Lab2_com;

	import java.util.Arrays;
	import java.util.Collections;
	import java.util.Scanner;

	public class Lab3_4 
	{

		public static void main(String[] args) 
		{
			Scanner sc = new Scanner(System.in);
		    System.out.println("Please enter length of String array");
		    int length = sc.nextInt();

		    // create a String array to save user input
		    String[] input = new String[length];

		    // loop over array to save user input
		    System.out.println("Please enter array elements");
		    for (int i = 0; i < length; i++) {
		    	 input[i] = sc.next();
		    }
		    
		    System.out.println("The array input from user is : ");
		    for (int i = 0; i < length; i++) {
		    	System.out.println(input[i]);
		    }
		    
		    //ascending order
		    Arrays.sort(input);
	        System.out.printf("Modified arr[] : \n%s\n\n", Arrays.toString(input));
		    //descending order
	        Arrays.sort(input, Collections.reverseOrder());
	        System.out.printf("Modified arr[] : \n%s\n\n", Arrays.toString(input));
		}

	}



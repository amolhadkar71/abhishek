package lab1;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class ZoneIdDate {

	/*
	 * (Hint: Few zones to test your code. America/New York, 
	 * Europe/London, 
	 * Asia/Tokyo, US/Pacific, Africa/Cairo, Australia/Sydney etc.)
	 */
	
	public static void getCurrentTimeWithTimeZone(){
	    LocalDateTime localtDateAndTime = LocalDateTime.now();
	    ZoneId zoneId = ZoneId.of("Australia/Sydney");
	    ZonedDateTime dateAndTimeInLA  = ZonedDateTime.of(localtDateAndTime, zoneId);
	    String currentTimewithTimeZone =dateAndTimeInLA.getDayOfMonth()+"/"+dateAndTimeInLA.getMonth()+"/"+dateAndTimeInLA.getYear()+"--"+dateAndTimeInLA.getHour()+":"+dateAndTimeInLA.getMinute();
	    System.out.println("Current Date and time in Los Angeles: " + currentTimewithTimeZone);
	}
	public static void main(String[] args) {

		getCurrentTimeWithTimeZone();

	}

}

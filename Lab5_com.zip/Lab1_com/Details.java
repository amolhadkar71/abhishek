package Lab_work;

import java.util.Scanner;

public class Details 
{

	

			public static void main(String[] args)
			{
			
			System.out.println("Enter person details");
			Scanner a=new Scanner(System.in);
			String Firstname=a.nextLine();
			String Lastname=a.nextLine();
			char Gender=a.next().charAt(0);
			int age=a.nextInt();
			double weight=a.nextDouble();
			System.out.println("Person Details:");
			System.out.println("---------------------");
			System.out.println("First Name:"+Firstname);
			System.out.println("Last Name:"+Lastname);
			System.out.println("Gender:"+Gender);
			System.out.println("Age:"+age);
			System.out.println("Weight:"+weight);
			}

		


	}


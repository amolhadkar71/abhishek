package lab1;

import java.util.Scanner;

class CheckPositveString{
	public boolean checkPositiveString(String word){
		for(int i=0;i<word.length();i++){
			if((i<word.length()-1)&&(word.charAt(i)>word.charAt(i+1))){
				return false;
			}
		}
		return true;
	}
}
public class PositiveString {

	public static void main(String[] args) {
		String word;
		Scanner in=new Scanner(System.in);
		word=in.nextLine();
		CheckPositveString obj=new CheckPositveString();
		if(obj.checkPositiveString(word)){
			System.out.println("Positive String");
		}
		else
		{
			System.out.println("Negative String");
		}

	}

}

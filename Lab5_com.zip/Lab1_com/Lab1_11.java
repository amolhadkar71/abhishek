package Lab_work;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.steadystate.css.parser.ParseException;

public class Lab1_11
{


	
	

		public static void main(String args[]) throws ParseException {
			
				LocalDate today = LocalDate.now();
				System.out.println(today);
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter date in dd/MM/yyyy format: ");
				String input = sc.nextLine();

				LocalDate enteredDate = LocalDate.parse(input, formatter);
				Period period = enteredDate.until(today);

				System.out.println("Days: " + period.getDays());
				System.out.println("Months:" + period.getMonths());
				System.out.println("Years:" + period.getYears());
			
			
		}
}

	

	
	
	
package lab1;

import java.util.Date;
import java.util.Scanner;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.Period.*;

public class CurrentDateDuration1 {

	public static void main(String[] args) throws ParseException {
		System.out.println("Enter a date in before current date in dd/mm/yyyy format");
		Scanner in=new Scanner(System.in);
		String date=in.nextLine();
		String dates[]=date.split("/");
		int year=Integer.parseInt(dates[2]);
		int month=Integer.parseInt(dates[1]);
		int day=Integer.parseInt(dates[0]);
		
		LocalDate endofCentury = LocalDate.of(year, month, day);
		LocalDate now = LocalDate.now();
		 
		Period diff = Period.between(endofCentury, now);
		 
		System.out.printf("Difference is %d years, %d months and %d days old",
		                    diff.getYears(), diff.getMonths(), diff.getDays());

	}

}

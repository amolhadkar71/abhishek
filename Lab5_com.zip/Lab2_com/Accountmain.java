package Lab2_com;

public class Accountmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1=new Person("Smith",35);
		Account a1=new Account(2000, p1);
		Person p2=new Person("Kathy",35);
		Account a2=new Account(3000, p2);
		a1.deposit(2000);
		a2.withdraw(2000);
		a1.print();
		a2.print();
	}

}

package com.capgemini.hbms.service;

import java.util.Date;
import java.util.List;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;

public interface IHotelService {

	//verify admin login function
		public boolean verifyLogin(int id,String password);
		public boolean verifyCustLogin(int id,String password);
		
		
		//Admin operations
		
		//Hotel Operations
		public int addHotel(Hotel hotel);
		public boolean deleteHotel(int hotelId);
		public Hotel modifyHotel(String hotelDesc,double avgRate,int hotelId);
		
		//Room operations
		public int addRoom(RoomDetails room);
		public boolean deleteRoom(int roomId);
		public RoomDetails modifyRoom(int roomId,double rent);
		public List<RoomDetails> getRoomList();
		
		//Generate Lists 
		public List<Hotel> getHotelList();
		public BookingDetails getBookingDetails(int roomId);
		public List<RoomDetails> getRoomListByHotelId(int hotelId);
		public List<BookingDetails> getBookingDetailsByDate(Date bookingDate);
		public List<Users> getGuestListByHotel_Id(int hotel_id);
		//Add Booking Details
		public int addBookingDetails(BookingDetails bookingDetails);
		
		//to calculate amount
//		public BookingDetails calculateBookingAmount(double rate,String date1,String date2,int noOfAdults,int noOfChildren,int roomId,int userId);
		public BookingDetails calculateBookingAmount(double rate, String date1,String date2, int noOfAdults,int noOfChildren,int roomId,int userId);
		
		//Customer functions
		
		// search function
		
		public List<Hotel> getHotelListByCity(String city);
		public List<RoomDetails> getRoomListByHotelIdAndType(int hotelId);
		public List<BookingDetails> getBookingDetailsByBookingId(int bookingId);
		
		//user registration
		public int addUser(Users user);
		public Users getUser(int userId);
		
		//Update Room Availability
		public RoomDetails updateRoomAvailability(int room_id);

}

//package com.cg.studentapp.bean;

import java.util.Scanner;
public class Student {
	int sid,rno;
	String sname,dob,age;
	char gender;
	static{
		
	}
	public Student() {
		
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getRno() {
		return rno;
	}

	public void setRno(int rno) {
		this.rno = rno;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public Student(int sid, int rno, String age, String sname, String dob,
			char gender) {
		super();
		this.sid = sid;
		this.rno = rno;
		this.age = age;
		this.sname = sname;
		this.dob = dob;
		this.gender = gender;
	}

	
	//studentvalidate() 
	
}

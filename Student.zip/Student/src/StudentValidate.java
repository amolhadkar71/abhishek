//package com.cg.studentapp.service;

import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import com.cg.studentapp.bean.Student;
//import com.cg.studentapp.exception.MyException;

public class StudentValidate {
	Student s1;
	public void studentValidate(String sname,String age) throws MyException
	{
		//sname=s1.getSname();
		
		Pattern p1=Pattern.compile("^[A-Za-z]{4,10}$");
		Matcher m1=p1.matcher(sname);
		Pattern p2=Pattern.compile("^[0-9]{2}$");
		Matcher m2=p2.matcher(age);
		//Pattern p3=Pattern.compile("^[0-9]{2}\\[0-9]{2}\\[0-9]{4}$");
		//Matcher m3=p3.matcher(dob);
		if(!m1.find())
		{
			throw new MyException("Entered name does not meet req");
			//System.err.println("Entered name does not meet req ");
			
		}
		if(!m2.find())
		{
			throw new MyException("Entered age does not meet req");
			
		}
		//if(!m3.find())
		//{
			//throw new MyException("Entered DOB does not meet req");
			
		//}
	}
}

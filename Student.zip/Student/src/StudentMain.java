//package com.cg.studentapp.pl;

import java.util.Scanner;

import com.sun.org.apache.bcel.internal.generic.GOTO;

/*import com.cg.studentapp.bean.Student;
import com.cg.studentapp.exception.MyException;
import com.cg.studentapp.service.StudentValidate;
*/
public class StudentMain {
	Student s1=new Student();
	//StudentMain sm=new StudentMain();
	StudentValidate s2=new StudentValidate();
	StaticPrg sp=new StaticPrg();
	Scanner sc=new Scanner(System.in);
	int sid,rno;
	String sname,dob,age;
	char gender;
	public static void main(String[] args) throws MyException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Do you want to Enter Student Details:");
		String ch=sc.next();
		
			switch(ch){
				
			case "yes":
					new StudentMain().acceptData();
					System.out.println("Do you want to continue");
					String a=sc.next();
					if(a=="yes")
						new StudentMain().acceptData();

					else if(a=="total")
						break;
					
					else if(a=="no")
						ch="exit";
						
				
			case "total"		
						:System.out.println(new StaticPrg().countTotStudents());
						break;
			case "exit":
				System.out.println("Gud bye");
			default:
			}
				}


public void display(int sid,String name,int rno,String age,String dob,char gender)
{
	System.out.println("Student Id:"+sid);
	System.out.println("Student Name:"+name);
	System.out.println("Student Gender:"+gender);
	System.out.println("Student DOB:"+dob);
	System.out.println("Student Rno:"+rno);
	System.out.println("Student Age"+age);
}
public void acceptData() throws MyException
{
	System.out.println("Enter Student Id:");
	sid=sc.nextInt();
	s1.setSid(sid);

	System.out.println("Enter Student Name:");
	String name=sc.next();
	s1.setSname(name); 
	
	
	System.out.println("Enter Student Roll No:");
	rno=sc.nextInt();
	s1.setRno(rno);


	System.out.println("Enter Student Age:");
	age=sc.next();
	s1.setAge(age);

	System.out.println("Enter Student DOB:");
	dob=sc.next();
	s1.setDob(dob);

	System.out.println("Enter Student gender:");
	gender=sc.next().charAt(0);
	s1.setSid(sid);
	StudentValidate sv=new StudentValidate();
	sv.studentValidate(name, age);
	new StudentMain().display(sid,name,rno,age,dob,gender);
	new StaticPrg().addStudent(s1);
	//new StudentMain().display();
}
}

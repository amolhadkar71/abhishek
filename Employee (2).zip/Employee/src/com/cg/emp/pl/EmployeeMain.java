package com.cg.emp.pl;

import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Set;

import com.cg.emp.bean.Employee;
import com.cg.emp.service.EmployeeStaticPrg;
import com.cg.emp.service.EmployeeValidate;
import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;



public class EmployeeMain {
	static EmployeeStaticPrg esp=new EmployeeStaticPrg();
	static EmployeeValidate ev=new EmployeeValidate();
	static Scanner sc = new Scanner(System.in);
	static Employee emp = new Employee();
	
	
	//public static Set<Employee> set1=new HashSet<>();
	//static int empid1;
	static String ename1 , dob1,empid1,salary1;
	
	//static Employee e1=new Employee("E002", "Bmol", "11/11/2017", 12000);
	
	public static void main(String[] args) throws EmployeeException { 
		ops(); 
		//esp.addEmployee(e1);
		}
	public static void ops() throws EmployeeException {
		
		
		String choice;
		//while(true)
		do{
		
			System.out.println("\nEmployee Management\n********\n1.Insert Details\n"+"2.Total Count\n"+"3.Exit\n");
			System.out.println("Enter your choice: ");
			choice=sc.next();
			switch(choice)
			{
			case "1":System.out.println("How many records you want to enter:");
					int a=sc.nextInt();
					for(int i=1;i<=a;i++)
					{
						enterEmployeeDetails();
						continue;
					}
					printDetails();
					break;
			case "2":totalEmployee();
					
					break;
			case "3":System.out.println("Exit");
			     	System.exit(0);
			     	break;
			default:System.out.println("Please enter correct choice");
					break;
			}
		
		}while(true);
	}
	private static void totalEmployee() {
		System.out.println("Total entries: "+esp.countTotEmployee());
		//ops();
	}
	public static  String enterEmpId()
	{
		try{
			System.out.println("Enter empid: ");
			empid1=sc.next();
			//emp.setEmpid(empid1);
			ev.isIDValid(empid1);
		}
		catch(EmployeeException e)
		{
			System.err.println("Empid shld start with capital");
			enterEmpId();
		}
		return empid1;
	}
	public static  String enterEmpName()
	{
		try{
			System.out.println("Enter ename: ");
			ename1=sc.next();
			//emp.setEmpname(ename1);
			ev.isNameValid(ename1);
		}
		catch(EmployeeException e)
		{
			System.err.println("EmpName shld start with capital");
			enterEmpName();
		}
		return ename1;
	}

	public static String enterEmpSal() throws EmployeeException
	{
		
		try{
			System.out.println("Enter salary: ");
			salary1=sc.next();
			ev.isSalaryValid(salary1);
			//emp.setSalary(salary1);
		}
		
		catch(EmployeeException e)
		{
			
			//throw new EmployeeException("Salary range exception");
			System.err.println("Emp salary shld contains nos 4 to 6");
			enterEmpSal();
		}
		
		return salary1;
	}
	public static String enterEmpDate()
	{
		try{
			System.out.println("Enter dob: ");
			dob1=sc.next();
			//emp.setDob(dob1);
			ev.isDOBValid(dob1);
		}
		catch(EmployeeException e)
		{
			System.err.println("Enter proper date");
		}
		return dob1;
	}
	
	
	private static void enterEmployeeDetails() throws EmployeeException {
		String empid= enterEmpId();
		String empname = enterEmpName();
		String sal =enterEmpSal();
		String date=enterEmpDate();
		emp=new Employee(empid, empname, date, sal);
		esp.addEmployee(emp);	
	}

	private static void printDetails() {
		esp.displaytotal();
	}

}

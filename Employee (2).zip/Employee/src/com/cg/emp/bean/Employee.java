package com.cg.emp.bean;

public class Employee {
	private String empname,dob,empid,salary;
	
	public Employee() {
		
	}
	public Employee(String empid, String empname, String dob, String salary) {
		
		this.empid = empid;
		this.empname = empname;
		this.dob = dob;
		this.salary = salary;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee Details \nEmployee name=" + empname + "\n Date of birth=" + dob + "\n Employee Id="
				+ empid + "\nSalary=" + salary ;
	}
	
	
}

package com.cg.emp.test;







import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.pl.EmployeeMain;
import com.cg.emp.service.*;



public class TestEmployee {

	EmployeeStaticPrg sp=new EmployeeStaticPrg();
	EmployeeValidate ev=new EmployeeValidate();
	EmployeeMain em=new EmployeeMain();
	Employee e1=new Employee();
	@Test
	public void countTest()
	{
		assertNotNull(sp.countTotEmployee());
	}
	
	@Test//(expected=MyEmployeeException.class)
	public void testEmpIdException() throws EmployeeException
	{
		String id=em.enterEmpId();
		assertEquals("E001",id);
		System.out.println("Testing Of ID Exception");
		
	}
	
	@Test//(expected=EmployeeException.class)
	public void testEmpNameException() throws EmployeeException 
	{
		String name=em.enterEmpName();
		assertEquals("Amol",name);
		System.out.println("Testing Of Name Exception");
		
	}
	
	
	@Test
	//(expected=MyEmployeeException.class)
	public void testEmpSalException() throws EmployeeException
	{
		String sal=em.enterEmpSal();
		
		assertEquals("20000", sal);
		System.out.println("Testing Of Sal Exception");
	}
	
	@Test
	//(expected=MyEmployeeException.class)
	public void testEmpDOBException() throws EmployeeException
	{
		String dob=em.enterEmpDate();
		assertEquals("12/12/1222", dob);
		System.out.println("Testing Of DOB Exception");
		
	}
	
	@Test
	public void notnullidtest()
	{
		//String id=em.enterEmpId();
		assertNotNull(e1.getEmpid(),"Correct");
		//System.out.println("Testing of not null id");
	}
	
	@Test
	public void notnullnametest()
	{
		
		assertNotNull(e1.getEmpname(),"Correct");
		//System.out.println("Testing of not null name");
	}
	
	@Test
	public void notnullsaltest()
	{
		
		//String sal=String.valueOf(e1.getSalary());
		assertNotNull(e1.getSalary(),"Correct");
		//System.out.println("Testing of not null sal");
	}
	
	@Test
	public void notnulldobtest()
	{
		System.out.println("Testing of not null dob");
		String sal=String.valueOf(e1.getDob());
		assertNotNull(sal,"Correct");
	}
	
	
	public void countTest1() 
	{
		assertEquals(sp.countTotEmployee()>2, 3);
	}
	
}

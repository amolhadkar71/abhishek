package com.cg.day4.lesson11;

public class StudentValidater {

	
	// implement each validateMethod
	
	public boolean isRollValid(String roll)throws StudentException{
		return false;
	}
}

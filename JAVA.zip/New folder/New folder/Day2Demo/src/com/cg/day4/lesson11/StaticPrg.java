package com.cg.day4.lesson11;

import java.util.HashSet;
import java.util.Set;

public class StaticPrg {

	private static Set<Student> obj;
	
	static{
		obj=new HashSet<>();
		Student stud1=new Student(1,"sam");
		
		obj.add(stud1);
		stud1=new Student(2,"ravi");
		obj.add(stud1);
		
		
	}
	public static Set<Student> getObj() {
		return obj;
	}
	public static void setObj(Set<Student> obj) {
		StaticPrg.obj = obj;
	}
	// business methods
	
	public void addStudent(Student stud){
		obj.add(stud);
	}
	
	public int countTotStudents(){
		return obj.size();
	}
	
	
	
}

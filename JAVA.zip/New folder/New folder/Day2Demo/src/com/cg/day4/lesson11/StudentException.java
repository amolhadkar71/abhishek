package com.cg.day4.lesson11;

public class StudentException extends Exception {

	public StudentException(String msg){
		super(msg);
	}
}

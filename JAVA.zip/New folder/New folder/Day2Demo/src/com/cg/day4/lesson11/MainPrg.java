package com.cg.day4.lesson11;

import java.util.Scanner;

public class MainPrg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try{
		StaticPrg obj = new StaticPrg();
		//switch case
		Scanner scan= new Scanner(System.in);
		//System.out.println("Enter your choice (1 , 2 , 3)");
		System.out.println("1. Add a new student");
		System.out.println("2. Show total number ");
		System.out.println("3. Exit");
		String ch = scan.next();
		switch(ch){
		case "1":
			new MainPrg().acceptStudent();
			break;
			
		case "2":
			System.out.println(obj.countTotStudents());
			break;
			
		case "3":
			
			default:
				
		}
}catch(StudentException exp){
	
	System.err.println(exp.getMessage);
}
		//System.out.println(obj.countTotStudents());
	
	//obj.addStudent(new Student(1,"ds"));
	//System.out.println(obj.countTotStudents());
	
	}
	
	public void acceptStudent()throws StudentException{
		
		// call validate method after data accept from user
		StudentValidater val = new StudentValidater();
		val.isRollValid(roll);
		//----
		
		//Student stud=new Student(roll, name);
		
		new StaticPrg().addStudent(stud);
	}

}

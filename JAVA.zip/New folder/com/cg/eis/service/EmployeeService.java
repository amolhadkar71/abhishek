package com.cg.eis.service;

public interface EmployeeService {
	public String empScheme(double sal);
}

package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.bean.Employee.*;

public class Service implements EmployeeService
{

	@Override
	public String empScheme(double sal) {
		Employee e=new Employee();
		
		
		if(sal>5000&&sal<20000)
			return "Scheme C";
		else if(sal>=20000 && sal<40000)
			return "Scheme B";
		else if(sal>=40000)
			return "Scheme A";
		else if(sal<5000)
			return "No Scheme";
		else
			return "GM";
		
		
		
	}
	
}

package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.Service;

public class EmpDisplay {

	public static void main(String[] args) {
		Employee e1=new Employee();
		Service s=new Service() ;
	
		Scanner sc=new Scanner(System.in);
		System.out.println("Employee Details");
		//id,name,des,salary,s
		
		System.out.println("Enter Emp Id:");
		String id=sc.next();
		e1.setId(id);
		
		System.out.println("Enter Emp Name:");
		String name=sc.next();
		e1.setName(name);
		
		System.out.println("Enter Emp Designation:");
		String des=sc.next();
		e1.setDesignation(des);
		
		System.out.println("Enter Emp Salary:");
		double sal=sc.nextDouble();
		e1.setSalary(sal);
		
		//System.out.println("Enter Emp Insurance Scheme:");
		//String scheme=sc.next();
		
		String scheme=s.empScheme(sal);
		e1.setInsuranceScheme(scheme);
		//e1.setInsuranceScheme();
		
		
		System.out.println("Emp id:"+e1.getId()+"\nEmp Name:"+e1.getName()+"\nEmp Designation:"+e1.getDesignation()+"\nEmp Salary:"+e1.getSalary()+"\nEmp Insurance:"+e1.getInsuranceScheme());

	}

}

package com.cg.studentapp.pl;

import java.util.Scanner;

import com.cg.studentapp.bean.Student;
import com.cg.studentapp.exception.MyException;
import com.cg.studentapp.service.StudentValidate;

public class StudentMain {
	
	public static void main(String[] args) {
		Student s1=new Student();
		StudentValidate s2=new StudentValidate();
		Scanner sc=new Scanner(System.in);
		int sid,rno;
		String sname,dob,age;
		char gender;
		System.out.println("Do you want to Enter Student Details:");
		String ch=sc.next();
		//do{
			switch(ch){
				
				case "yes":
						System.out.println("Enter Student Id:");
						sid=sc.nextInt();
						s1.setSid(sid);
		
						System.out.println("Enter Student Name:");
						String name=sc.next();
						s1.setSname(name); 
						
						
						System.out.println("Enter Student Roll No:");
						rno=sc.nextInt();
						s1.setRno(rno);
		
		
						System.out.println("Enter Student Age:");
						age=sc.next();
						s1.setAge(age);
		
						System.out.println("Enter Student DOB:");
						dob=sc.next();
						s1.setDob(dob);
		
						System.out.println("Enter Student gender:");
						gender=sc.next().charAt(0);
						s1.setSid(sid);
				try {
					s2.studentValidate(name,age,dob);
				} catch (MyException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
						ch="display";
						
						
			
		case "display":
			System.out.println("Student Id:"+s1.getSid());
			System.out.println("Student Name:"+s1.getSname());
			System.out.println("Student Gender:"+s1.getGender());
			System.out.println("Student DOB:"+s1.getDob());
			System.out.println("Student Rno:"+s1.getRno());
			System.out.println("Student Age"+s1.getAge());
			System.out.println("Do you want to continue");
			String ans=sc.next();
			if(ans=="yes")
				{
				ch="yes";
				//continue;
				}
			else
				ch="no";
			
		
			
		case "no":
			System.out.println("DONE");
			break;
		}
		//}while(true);
	}

}

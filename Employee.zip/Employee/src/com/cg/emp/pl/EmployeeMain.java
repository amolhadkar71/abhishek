package com.cg.emp.pl;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.cg.emp.bean.Employee;
import com.cg.emp.service.EmployeeStaticPrg;
import com.cg.emp.service.EmployeeValidate;
import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;



public class EmployeeMain {

	static Scanner sc = new Scanner(System.in);
	static Employee emp = new Employee();
	static EmployeeStaticPrg esp=new EmployeeStaticPrg();
	static EmployeeValidate ev=new EmployeeValidate();
	//public static Set<Employee> set1=new HashSet<>();
	//static int empid1;
	static String ename1 , dob1,empid1;
	static double salary1;
	public static void main(String[] args) throws EmployeeException { 
		ops(); 
		}
	public static void ops() throws EmployeeException {
		
		
		String choice;
		while(true)
		{
			System.out.println("\nEmployee Management\n********\n1.Insert Details\n"+"2.Total Count\n"+"3.Exit\n");
			System.out.println("Enter your choice: ");
			choice=sc.next();
			switch(choice)
			{
			case "1":System.out.println("How many records you want to enter:");
					int a=sc.nextInt();
					for(int i=1;i<=a;i++)
					{
						enterEmployeeDetails();
						
					}
					printDetails();
					break;
			case "2":totalEmployee();
					
					break;
			case "3":System.out.println("Exit");
			     	System.exit(0);
			     	break;
			default:System.out.println("Please enter correct choice");
					break;
			}
		}
		
	}
	private static void totalEmployee() {
		System.out.println("Total entries: "+esp.countTotEmployee());
		//ops();
	}
	private static void enterEmployeeDetails() throws EmployeeException {
		
		System.out.println("Enter empid: ");
		empid1=sc.next();
		emp.setEmpid(empid1);
		ev.isIDValid(empid1);
		
		System.out.println("Enter ename: ");
		ename1=sc.next();
		emp.setEmpname(ename1);
		ev.isNameValid(ename1);
		
		System.out.println("Enter salary: ");
		salary1=sc.nextDouble();
		String salary=String.valueOf(salary1);
		ev.isSalaryValid(salary);
		emp.setSalary(salary1);
		
		System.out.println("Enter dob: ");
		dob1=sc.next();
		emp.setDob(dob1);
		ev.isDOBValid(dob1);
		esp.addEmployee(emp);	
	}

	private static void printDetails() {
		esp.displaytotal();
	}

}

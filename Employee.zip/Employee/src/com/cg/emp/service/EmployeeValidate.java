package com.cg.emp.service;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.emp.exception.EmployeeException;

public class EmployeeValidate {

	public boolean isNameValid(String empname)throws EmployeeException{
		
		Pattern p1=Pattern.compile("[a-zA-Z]+\\.?",Pattern.CASE_INSENSITIVE);
		Matcher m1=p1.matcher(empname);
		if(!m1.find())
			throw new EmployeeException("Emp Name does not match req");
		return false;
	}
	public boolean isIDValid(String id)throws EmployeeException{
		Pattern p1=Pattern.compile("^[A-Z0-9]{2,4}");
		Matcher m1=p1.matcher(id);
		if(!m1.find())
			throw new EmployeeException("Emp Id does not match req");
		return false;
	}
	public boolean isDOBValid(String dob)throws EmployeeException{
		//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		//LocalDate enteredDate = LocalDate.parse(dob,formatter);
		//Pattern p1=Pattern.compile("^[0-9]{2}\\[0-9]{2}\\[0-9]{4}");
		//Matcher m1=p1.matcher(dob);
		String s="dd/MM/yyyy";
		//if(!m1.find())
		//	throw new EmployeeException("Emp DOB does not match req");
		SimpleDateFormat sdfrmt = new SimpleDateFormat("MM/dd/yyyy");
	    sdfrmt.setLenient(false);
	    /* Create Date object
	     * parse the string into date 
             */
	    try
	    {
	        Date javaDate = sdfrmt.parse(dob); 
	        System.out.println(dob+" is valid date format");
	    }
	    /* Date format is invalid */
	    catch (ParseException e)
	    {
	        System.out.println(dob+" is Invalid Date format");
	        return false;
	    }
	    /* Return true if date format is valid */
	    return true;
	}
	}
	public boolean isSalaryValid(String sal)throws EmployeeException{
		Pattern p1=Pattern.compile("^[0-9]{4,6}");
		Matcher m1=p1.matcher(sal);
		if(!m1.find())
			throw new EmployeeException("Emp Name does not match req");
		return false;
	}
}

package com.cg.emp.service;

import java.util.ArrayList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import com.cg.emp.bean.Employee;

public class EmployeeStaticPrg {
	private static ArrayList<Employee> emp;
	static{
		emp=new ArrayList<>();
		Employee e1=new Employee("E001", "Amol", "10/11/2017", 12000);
		emp.add(e1);
	}
	
	public static ArrayList<Employee> getObj() {
		return emp;
	}
	public static void setObj(ArrayList<Employee> obj) {
		EmployeeStaticPrg.emp = obj;
	}
	
	public static void displaytotal()
	{
		Iterator<Employee> i=emp.iterator();
		for(Object obj:emp)
		{
			System.out.println(obj);
		}
	}
	public void addEmployee(Employee stud){
		emp.add(stud);
	}
	
	public int countTotEmployee(){
		return emp.size();
	}
}

package com.test.service;

import java.util.Collection;

import com.test.bean.Employee;

public interface IEmployeeService {

	public boolean addEmployee(Employee bean);
	public Employee deleteEmployee(int id);
	public Collection<Employee> viewAll();
	public Employee updateEmployee(int id,Employee emp);
}

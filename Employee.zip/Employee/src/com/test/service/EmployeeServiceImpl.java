package com.test.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.bean.Employee;
import com.test.dao.IEmployeeDao;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeDao employeeDao;
	
	@Override
	public boolean addEmployee(Employee bean) {
		
		return employeeDao.addEmployee(bean);
	}

	@Override
	public Employee deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return employeeDao.deleteEmployee(id);
	}

	@Override
	public Collection<Employee> viewAll() {
		// TODO Auto-generated method stub
		return employeeDao.viewAll();
	}

	@Override
	public Employee updateEmployee(int id, Employee emp) {
		// TODO Auto-generated method stub
		return employeeDao.updateEmployee(id, emp);
	}

}

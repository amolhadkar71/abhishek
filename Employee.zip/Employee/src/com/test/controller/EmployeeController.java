package com.test.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.test.bean.Employee;
import com.test.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService employeeService;
	
	@RequestMapping("/show")
	public String showHomePage(){
		return("index");
	}

	@RequestMapping("/add")
	public String addPage(){
		return ("addemp");
	}

	
	@RequestMapping("/addSuccess")
	public String addEmployee(@ModelAttribute("emp") Employee emp,BindingResult result){
		
		boolean status = employeeService.addEmployee(emp);
		if(result.hasErrors()){
			return("error");
		}else if(status == false){
			return("error2");
		}
		return ("addempdetail");
	}

	@RequestMapping("/delete")
	public String deletePage(){
		return ("delete");
	}

	
	@RequestMapping("/deleteSuccess")
	public ModelAndView deleteEmployee(@RequestParam("id") int id){
		
		Employee em = employeeService.deleteEmployee(id);
		
		ModelAndView mv = new ModelAndView("deleteemp","em",em);
		
		return mv;
	}

	
	@RequestMapping("/view")
	public ModelAndView viewPage(){
		 Collection<Employee> c = employeeService.viewAll();
		
		 ModelAndView mv = new ModelAndView("view","c",c);
		 
		 return mv;
	}
	
	@RequestMapping("/update")
	public String updatePage(){
		return ("update");
	}
	
	@RequestMapping("/updateSuccess")
	public ModelAndView updateEmployee(@ModelAttribute("emp") Employee emp){
		
		Employee em = employeeService.updateEmployee(emp.getEmployeeId(), emp);
		
		ModelAndView mv = new ModelAndView("updateemp","emp",em);
		
		return mv;
	}
}

package com.test.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.test.bean.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {

	private Map<Integer,Employee> map = new HashMap<Integer,Employee>();
	@Override
	public boolean addEmployee(Employee bean) {
		map.put(bean.getEmployeeId(), bean);
		return true;
	}
	@Override
	public Employee deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return map.remove(id);
	}
	@Override
	public Collection<Employee> viewAll() {
		
		return map.values();
	}
	@Override
	public Employee updateEmployee(int id,Employee emp) {
		// TODO Auto-generated method stub
		return map.put(id, emp);
	}

}

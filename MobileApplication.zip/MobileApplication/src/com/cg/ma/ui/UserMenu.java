package com.cg.ma.ui;

public enum UserMenu {
	ADD,SEARCH,DISPLAY,DELETE,QUIT;
}

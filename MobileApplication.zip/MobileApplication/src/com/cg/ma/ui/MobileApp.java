package com.cg.ma.ui;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.ma.dto.MobileDetail;
import com.cg.ma.dto.PurchaseDetail;
import com.cg.ma.exception.MobileException;
import com.cg.ma.service.IMobileService;
import com.cg.ma.service.MobileServiceImpl;

public class MobileApp {

	static IMobileService service;
	static Scanner scan;

	public static void main(String[] args) {
		try{
			service = new MobileServiceImpl();
			System.out.println("Service Started");
		}catch(MobileException exp){
			System.out.println(exp.getMessage());
			System.exit(0);
		}
		
		PropertyConfigurator.configure("resources/log4j.properties");
		UserMenu choice = null;
		scan = new Scanner(System.in);
		
		while(choice != UserMenu.QUIT){
			System.out.println("**********Mobile Book**********");
			for(UserMenu menu : UserMenu.values()){
				System.out.println(menu.ordinal() + "\t" + menu.name());
			}
			
			System.out.print("Enter choice : ");
			int ordinal = scan.nextInt();
			
			if(ordinal < 0 || ordinal > UserMenu.QUIT.ordinal()){
				System.out.println("Invalid Choice");
				continue;
			}
			
			choice = UserMenu.values()[ordinal];
			
			switch(choice){
			case ADD:
				doAdd();
				break;
			case DELETE:
				doDelete();
				break;
			case SEARCH:
				doSearch();
				break;
			case DISPLAY:
				doDisplay();
				break;
			case QUIT:
				System.out.println("Thank You!");
				break;
			}
		}
		scan.close();
	}

	public static void doAdd(){
		PurchaseDetail purchase = new PurchaseDetail();
		
		System.out.print("Enter name : ");
		purchase.setName(scan.next());
		System.out.print("Enter Mobile Number : ");
		purchase.setPhoneNo(scan.next());
		System.out.print("Enter Email Id : ");
		purchase.setMailId(scan.next());
		System.out.print("Enter purchase date : ");
		purchase.setPurchaseDate(scan.next());
		System.out.print("Enter Mobile Id : ");
		purchase.setMobileId(scan.nextInt());
		
		try {
			int isSuccessful  = service.add(purchase);
			if(isSuccessful > 0){
				System.out.println("Purchase Detail successfully added and id is " + isSuccessful);
			}
			else{
				System.out.println("Purchase Detail could not added");
			}
		} catch (MobileException e) {
			System.err.println(e.getMessage());
		}
	}
	
	public static void doDelete(){
		System.out.print("Enter Mobile Id : ");
		int mobid = scan.nextInt();
		try {
			MobileDetail mobile = service.get(mobid);
			if(mobile == null){
				System.out.println("Mobile Id doesn't exist");
			}
			else{
				boolean isSuccessful = service.delete(mobile.getMobileId());
				if(isSuccessful){
					System.out.println("Mobile Detail successfully deleted");
				}
				else{
					System.out.println("Mobile Detail not deleted");
				}
			}
		} catch (MobileException e) {
			System.err.println(e.getMessage());
		}
	}
	
	public static void doSearch(){
		System.out.print("Enter Start Price : ");
		double start = scan.nextDouble();
		System.out.print("Enter End Price : ");
		double end = scan.nextDouble();
		try {
			List<MobileDetail> mobileList = service.search(start, end);
			if(mobileList.isEmpty()){
				System.out.println("There are no mobiles available for given price range");
			}
			else{
				for(MobileDetail list : mobileList){
					System.out.println(list);
				}
			}
		} catch (MobileException e) {
			System.err.println(e.getMessage());
		}
	}
	
	public static void doDisplay(){
		try {
			List<MobileDetail> mobileList = service.display();
			for(MobileDetail list : mobileList){
				System.out.println(list);
			}
		} catch (MobileException e) {
			System.err.println(e.getMessage());
		}
	}
}

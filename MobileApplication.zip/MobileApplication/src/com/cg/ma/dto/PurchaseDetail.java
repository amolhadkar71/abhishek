package com.cg.ma.dto;

public class PurchaseDetail {
	private int purchaseId;
	private String name;
	private String mailId;
	private String phoneNo;
	private String purchaseDate;
	private int mobileId;

	public PurchaseDetail() {

	}

	public PurchaseDetail(int purchaseId, String name, String mailId,
			String phoneNo, String purchaseDate, int mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.name = name;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	@Override
	public String toString() {
		return "PurchaseDetail [purchaseId=" + purchaseId + ", name=" + name
				+ ", mailId=" + mailId + ", phoneNo=" + phoneNo
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}

}

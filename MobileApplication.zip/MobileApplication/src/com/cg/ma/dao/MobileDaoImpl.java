package com.cg.ma.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ma.dto.MobileDetail;
import com.cg.ma.dto.PurchaseDetail;
import com.cg.ma.exception.MobileException;
import com.cg.ma.util.ConnectionProvider;

public class MobileDaoImpl implements IMobileDao {
	private Logger classLogger;
	private ConnectionProvider conPro;

	public MobileDaoImpl() throws MobileException {
		classLogger = Logger.getLogger(MobileDaoImpl.class);
		try {
			conPro = ConnectionProvider
					.getInstance("resources/dbconfig.properties");
		} catch (ClassNotFoundException | IOException e) {
			classLogger.error(e);
			throw new MobileException("Data Access Initiation Failed");
		}
	}

	public MobileDetail mapRow(ResultSet row) throws MobileException {
		MobileDetail mobile = new MobileDetail();
		try {
			mobile.setMobileId(row.getInt("mobileid"));
			mobile.setMobileName(row.getString("name"));
			mobile.setMobilePrice(row.getDouble("price"));
			mobile.setMobileQuantity(row.getInt("quantity"));
		} catch (SQLException e) {
			classLogger.error(e);
			throw new MobileException("Failed to retreive data");
		}
		return mobile;
	}

	public Integer mapId(ResultSet row) throws MobileException {
		try {
			Integer id = new Integer(row.getInt("mobileid"));
			return id;
		} catch (SQLException e) {
			classLogger.error(e);
			throw new MobileException("Failed to retreive data");
		}

	}

	@Override
	public int add(PurchaseDetail purchase) throws MobileException {
		int result = 0;
		try (Connection con = conPro.getConnection();
				PreparedStatement pstInsert = con
						.prepareStatement(IQueryMapper.INSERT_QRY);
				PreparedStatement pstUpdate = con
						.prepareStatement(IQueryMapper.UPDATE_QRY);
				PreparedStatement pstcurrVal = con
						.prepareStatement(IQueryMapper.CURR_VAL)) {
			con.setAutoCommit(false);
			pstInsert.setString(1, purchase.getName());
			pstInsert.setString(2, purchase.getMailId());
			pstInsert.setString(3, purchase.getPhoneNo());
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate purchaseDate = LocalDate.parse(purchase.getPurchaseDate(),formatter);
			pstInsert.setDate(4, java.sql.Date.valueOf(purchaseDate));
			pstInsert.setInt(5, purchase.getMobileId());

			int count = pstInsert.executeUpdate();
			if (count > 0) {
				pstUpdate.setInt(1, purchase.getMobileId());
				int row  = pstUpdate.executeUpdate();
				if (row > 0) {
					con.commit();
				}
			}
			
			ResultSet results = pstcurrVal.executeQuery();
			if(results.next()){
				result = results.getInt(1);
			}

		} catch (SQLException e) {
			classLogger.error(e);
			throw new MobileException("Data could not be added");
		}
		return result;
	}

	@Override
	public List<MobileDetail> display() throws MobileException {
		List<MobileDetail> mobileList = new ArrayList<>();
		try (Connection con = conPro.getConnection();
				PreparedStatement pstDisplay = con
						.prepareStatement(IQueryMapper.DISPLAY_QRY)) {
			ResultSet results = pstDisplay.executeQuery();
			while (results.next()) {
				mobileList.add(mapRow(results));
			}
		} catch (SQLException e) {
			classLogger.error(e);
			throw new MobileException("Data could not be retrieved");
		}

		return mobileList;
	}

	@Override
	public boolean delete(int mobid) throws MobileException {
		boolean result = false;
		try (Connection con = conPro.getConnection();
				PreparedStatement pstDelete = con
						.prepareStatement(IQueryMapper.DELETE_QRY)) {
			pstDelete.setInt(1, mobid);
			int count = pstDelete.executeUpdate();
			if (count > 0) {
				result = true;
			}
		} catch (SQLException e) {
			classLogger.error(e);
			throw new MobileException("Data could not be deleted");
		}

		return result;
	}

	@Override
	public List<MobileDetail> search(double startPrice, double endPrice)
			throws MobileException {
		List<MobileDetail> mobileList = new ArrayList<>();
		try (Connection con = conPro.getConnection();
				PreparedStatement pstSearch = con
						.prepareStatement(IQueryMapper.SEARCH_QRY)) {
			pstSearch.setDouble(1, startPrice);
			pstSearch.setDouble(2, endPrice);
			ResultSet results = pstSearch.executeQuery();
			while (results.next()) {
				mobileList.add(mapRow(results));
			}
		} catch (SQLException e) {
			classLogger.error(e);
			throw new MobileException("Data could not be retrieved");
		}

		return mobileList;
	}

	@Override
	public MobileDetail get(int mobid) throws MobileException {
		try (Connection con = conPro.getConnection();
				PreparedStatement pstGet = con
						.prepareStatement(IQueryMapper.GET_QRY)) {
			MobileDetail mobile = null;
			pstGet.setInt(1, mobid);

			ResultSet result = pstGet.executeQuery();
			if (result.next()) {
				mobile = mapRow(result);
			}
			return mobile;

		} catch (SQLException e) {
			classLogger.error(e);
			throw new MobileException("Data could not be retrieved");
		}
	}

	@Override
	public List<Integer> getId() throws MobileException {
		try (Connection con = conPro.getConnection();
				PreparedStatement pstGetId = con
						.prepareStatement(IQueryMapper.GET_ID_QRY)) {
			List<Integer> idList = new ArrayList<>();
			ResultSet result = pstGetId.executeQuery();
			while (result.next()) {
				idList.add(mapId(result));
			}
			return idList;

		} catch (SQLException e) {
			classLogger.error(e);
			throw new MobileException("Data could not be retrieved");
		}
	}
}

package com.cg.ma.dao;

public interface IQueryMapper {
	public static final String INSERT_QRY = "INSERT INTO purchasedetails(purchaseId,cname,mailid,phoneno,purchasedate,mobileid)VALUES(pidseq.NEXTVAL,?,?,?,?,?)";
	public static final String UPDATE_QRY = "UPDATE mobiles SET quantity = quantity - 1 WHERE mobileid =?";
	public static final String DISPLAY_QRY = "SELECT mobileid,name,price,quantity FROM mobiles";
	public static final String DELETE_QRY = "DELETE FROM mobiles WHERE mobileid=?";
	public static final String SEARCH_QRY = "SELECT mobileid,name,price,quantity FROM mobiles WHERE price BETWEEN ? AND ?";
	public static final String GET_QRY = "SELECT mobileid,name,price,quantity FROM mobiles WHERE mobileid = ?";
	public static final String GET_ID_QRY = "SELECT mobileid FROM mobiles";
	public static final String CURR_VAL = "SELECT pidseq.CURRVAL from DUAL";
}

package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.dto.MobileDetail;
import com.cg.ma.dto.PurchaseDetail;
import com.cg.ma.exception.MobileException;

public interface IMobileDao {
	public int add(PurchaseDetail purchase) throws MobileException;
	public List<MobileDetail> display() throws MobileException;
	public boolean delete(int mobid) throws MobileException;
	public List<MobileDetail> search(double startPrice,double endPrice) throws MobileException;
	public MobileDetail get(int mobid) throws MobileException;
	public List<Integer> getId() throws MobileException;
}

package com.cg.ma.exception;

@SuppressWarnings("serial")
public class MobileException extends Exception{
	public MobileException(String msg){
		super(msg);
	}
}

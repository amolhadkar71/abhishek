package com.cg.ma.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.MobileDetail;
import com.cg.ma.dto.PurchaseDetail;
import com.cg.ma.exception.MobileException;

public class MobileServiceImpl implements IMobileService {

	private IMobileDao dao = null;
	
	List<String> validationErrors;
	
	public MobileServiceImpl() throws MobileException{
		dao = new MobileDaoImpl();
	}
	
	public boolean isValidMobileId(int mobid) throws MobileException{
		boolean result = false;
		List<Integer> idList = dao.getId();
		for(Integer id : idList){
			if(mobid == id.intValue()){
				result = true;
				break;
			}
		}
		return result;
	}
	
	public boolean isValidName(String name){
		Pattern namePattern = Pattern.compile("[A-Z]{1}[a-z]{2,19}");
		Matcher nameMatcher = namePattern.matcher(name);
		return nameMatcher.matches();
	}
	
	public boolean isValidMobile(String mobile){
		Pattern mobilePattern = Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher mobileMatcher = mobilePattern.matcher(mobile);
		return mobileMatcher.matches();
	}
	
	public boolean isValidMail(String mail){
		Pattern mailPattern = Pattern.compile("[a-z]+([._]|[a-z]|[0-9])+@[a-z]+(.[a-z]+)?");
		Matcher mailMatcher = mailPattern.matcher(mail);
		return mailMatcher.matches();
	}
	
	public boolean isValidDate(String date){
		String currDate = LocalDate.now().toString();
		return currDate.equals(date);
	}
	
	public boolean isValidPurchase(PurchaseDetail purchase) throws MobileException{
		validationErrors = new ArrayList<>();
		if(purchase != null){
			if(!isValidMobileId(purchase.getMobileId())){
				validationErrors.add("Mobile Id doesn't exist");
			}
			if(!isValidName(purchase.getName())){
				validationErrors.add("Customer Name must not contain more than 20 characters and first character must be uppercase letter");
			}
			if(!isValidMobile(purchase.getPhoneNo())){
				validationErrors.add("Phone number must contain only 10 digits");
			}
			if(!isValidMail(purchase.getMailId())){
				validationErrors.add("Email Id is not valid");
			}
			if(!isValidDate(purchase.getPurchaseDate())){
				validationErrors.add("Purchase Date should be current date");
			}
		}
		return validationErrors.size() == 0 ? true : false;
	}
	
	@Override
	public int add(PurchaseDetail purchase) throws MobileException {
		int result = 0;
		if(isValidPurchase(purchase)){
			result = dao.add(purchase);
		}
		else{
			throw new MobileException("Can't have invalid purchase" + validationErrors);
		}
		return result;
	}

	@Override
	public List<MobileDetail> display() throws MobileException {
		return dao.display();
	}

	@Override
	public boolean delete(int mobid) throws MobileException {
		return dao.delete(mobid);
	}

	@Override
	public List<MobileDetail> search(double startPrice, double endPrice)
			throws MobileException {
		return dao.search(startPrice, endPrice);
	}

	@Override
	public MobileDetail get(int mobid) throws MobileException {
		return dao.get(mobid);
	}

}

DROP TABLE mobiles;

CREATE TABLE mobiles (
	mobileid NUMBER PRIMARY KEY, 
	name VARCHAR2 (20) NOT NULL, 
	price NUMBER(10,2) NOT NULL,
	quantity NUMBER NOT NULL
);

INSERT INTO mobiles VALUES(1001,�Nokia Lumia 520�,8000,20);
INSERT INTO mobiles VALUES(1002,�Samsung Galaxy IV�,38000,40);
INSERT INTO mobiles VALUES(1003,�Sony Xperia C�,15000,30);

DROP TABLE purchasedetails;

CREATE TABLE purchasedetails(
	purchaseid NUMBER PRIMARY KEY, 
	cname VARCHAR2(20) NOT NULL, 
	mailid VARCHAR2(30) UNIQUE,
	phoneno VARCHAR2(20) UNIQUE, 
	purchasedate DATE NOT NULL, 
	mobileid REFERENCES mobiles(mobileid)
);

DROP SEQUENCE pidseq;

CREATE SEQUENCE pidseq
START WITH 101
INCREMENT BY 1;
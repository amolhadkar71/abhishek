package com.capgemini.lesson13;


import static org.junit.Assert.*; 

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;


public class HelloWorlTest {
	HelloWorld hello;
	@Test
	public void testSay()
	{
		
		System.out.println("Test 1");
		assertEquals("Unexpected Result","Hello World!", hello.say());
	}
	@Test
	public void init()
	   {
			System.out.println("Test 2");
		   hello=new HelloWorld();
	   }
	
	@After
	public void destroy()
	{
		System.out.println("Last");
		
		hello=null;
	}
}

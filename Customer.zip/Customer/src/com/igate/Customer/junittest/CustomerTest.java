package com.igate.Customer.junittest;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.BeforeClass;
import org.junit.Test;

import com.igate.Customer.doa.CustomerDb;
import com.igate.Customer.doa.CustomerHelper;
import com.igate.Customer.dto.Customer;

public class CustomerTest {
	
	
	static Connection con;
	static CustomerHelper cu;
	
	@BeforeClass
	public static void checkConnection() {
		con=CustomerDb.getConnection();
		cu=new CustomerHelper();
	}

	@Test
	public void test() {
		//checking database connection....
		assertEquals("connection established","oracle.jdbc.driver.T4CConnection",
				       con.toString().substring(0,32));
		
		//checking inserting the company details.....
		Customer cm=new Customer();
		cm.setCustomerName("John");
		cm.setAccountType("PREPAID");
		cm.setMobileNumber("9876894534");
		assertEquals(1,cu.insertCustomer(cm));
	}

}




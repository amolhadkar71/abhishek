package com.igate.Customer.dto;

public class Customer {

	private long custid;
	private String customerName;
	private String accountType;
	private String mobileNumber;
	
	public Customer(){
		
	}
	
	public long getCustid() {
		return custid;
	}
	public void setCustid(long custid) {
		this.custid = custid;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", customerName=" + customerName
				+ ", accountType=" + accountType + ", mobileNumber="
				+ mobileNumber + "]";
	}

	public Customer(long custid, String customerName, String accountType,
			String mobileNumber) {
		super();
		this.custid = custid;
		this.customerName = customerName;
		this.accountType = accountType;
		this.mobileNumber = mobileNumber;
	}

}

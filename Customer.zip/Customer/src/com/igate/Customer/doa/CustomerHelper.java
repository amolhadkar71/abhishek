package com.igate.Customer.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.igate.Customer.dto.Customer;



public class CustomerHelper {

	Connection conn;
	Customer customer;
	int check;
	public long insertCustomer(Customer customer ){
		conn=CustomerDb.getConnection();
		//Inserting customer details in customer table
		String query="INSERT INTO  Customer VALUES(seq_cust_id.nextval,?,?,?)"; 
		try {
			PreparedStatement ptms=conn.prepareStatement(query);
			ptms.setString(1, customer.getCustomerName());
			ptms.setString(2,customer.getAccountType());
			ptms.setString(3,customer.getMobileNumber());
			check= ptms.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return check;
}
}

	


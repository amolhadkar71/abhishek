package com.igate.Customer.doa;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;


public class CustomerDb {
	private static Logger log=Logger.getLogger(CustomerDb.class);
	public static Connection con;
	public static Connection getConnection(){
	
		Properties props=new Properties();
		try {
			props.load(new FileInputStream("Customer.properties"));
			String driver=props.getProperty("db.driver");
			String url=props.getProperty("db.url");
			String userName=props.getProperty("db.user");
			String pass=props.getProperty("db.password");
			
			Class.forName(driver);
			
			con=DriverManager.getConnection(url, userName, pass);
			
			log.info("Connecting..........");
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException es) {
			es.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
}

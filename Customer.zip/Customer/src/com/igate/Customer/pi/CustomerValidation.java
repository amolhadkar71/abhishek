package com.igate.Customer.pi;

import java.util.regex.Pattern;

public class CustomerValidation {


		public static boolean validationData(String regx,String data){
			return Pattern.matches(regx,data);
			
		}
	
}

package com.igate.Customer.pi;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.igate.Customer.doa.CustomerHelper;
import com.igate.Customer.dto.Customer;
import com.igate.Customer.exception.CustomerException;


public class MyMain {
	static CustomerHelper addmobile = new CustomerHelper();
	private static Logger log = Logger.getLogger(Customer.class);

	public static void main(String[] args) {

		int choice;
		do {
			@SuppressWarnings("resource")
			Scanner scr = new Scanner(System.in);
			System.out.println("Available options for Customer Care Representative :");
			System.out.println("1 Insert Customer Record");
			System.out.println("2 Exit");
			System.out.println("_________________");
			System.out.println("enter your choice");

			choice = scr.nextInt();

			log.info("Choice selected...." + choice);

			switch (choice) {
			case 1:
				try {
					insertMobile();

				} catch (CustomerException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;

			case 2:
				System.exit(0);
				break;
			default:
				System.out.println("enter the right choice");
			}
		} while (choice != 2);

	}

	public static void insertMobile() throws CustomerException {
		log.info("In InsertMobile method...");
		@SuppressWarnings("resource")
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter Customer Name");
		String name = scr.next();
		String patname = "[A-Za-z]{3,20}";
		if (name.equals(""))
			throw new CustomerException("Customer Name should not be empty");
		if (!CustomerValidation.validationData(patname, name))
			throw new CustomerException(
					"Customer name should be 3-20 characters only");

		System.out.println("Enter Account Type 'POSTPAID'or'PREPAID'");
		String type = scr.next();
		if (type.equals(""))
			throw new CustomerException("Account Type should not be empty");
		if (!(type.equals("PREPAID") || type.equals("POSTPAID")))
			throw new CustomerException(
					"Account Type should be either PREPAID or POSTPAID only(CAPS)");

		System.out.println("Enter Mobile Number");
		String mobileNumber = scr.next();
		String patlocation = "[0-9]{10}";
		if (mobileNumber.equals(""))
			throw new CustomerException("Mobile Number should not be empty");
		if (!CustomerValidation.validationData(patlocation, mobileNumber))
			throw new CustomerException(
					"Mobile Number should be 10 digits only");

		Customer cm = new Customer();

		cm.setCustomerName(name);
		cm.setAccountType(type);
		cm.setMobileNumber(mobileNumber);

		CustomerHelper addmobile = new CustomerHelper();
		long status = addmobile.insertCustomer(cm);
		if (status == 1) {
			cm.getCustid();
			log.info("Table created");
		}
	}

}
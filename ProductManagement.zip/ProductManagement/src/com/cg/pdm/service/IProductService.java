package com.cg.pdm.service;

import com.cg.pdm.bean.Product;
import com.cg.pdm.exception.ProductException;

public interface IProductService {
	public boolean add(Product contact) throws ProductException;
	public Product get(int contId) throws ProductException;
}

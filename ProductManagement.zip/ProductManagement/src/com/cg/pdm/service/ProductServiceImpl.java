package com.cg.pdm.service;

import com.cg.pdm.bean.Product;
import com.cg.pdm.dao.IProductDao;
import com.cg.pdm.dao.ProductDao;
import com.cg.pdm.exception.ProductException;

public class ProductServiceImpl implements IProductService {

	private IProductDao dao = null;

	public ProductServiceImpl() throws ProductException {

		dao = new ProductDao();

	}

	public boolean add(Product prod) throws ProductException {
		boolean result = false;

		{
			result = dao.addProductDetails(prod);

		}

		return result;
	}

	public Product get(int prodId) throws ProductException {
		return dao.getProductDetails(prodId);

	}
}

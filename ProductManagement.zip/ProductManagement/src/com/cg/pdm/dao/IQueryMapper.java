package com.cg.pdm.dao;

public class IQueryMapper {

	public static final String INSERT_QUERY= "INSERT INTO PRODUCT(ProductId,ProductName,ProductQuantity,ProductCost) VALUES(?,?,?,?)";
	public static final String SELECT_PROD_BY_ID_QRY="SELECT FROM PRODUCT WHERE ProductId=?";
}

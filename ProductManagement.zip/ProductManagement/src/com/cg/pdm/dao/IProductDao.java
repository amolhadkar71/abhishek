package com.cg.pdm.dao;

import com.cg.pdm.bean.Product;
import com.cg.pdm.exception.ProductException;

public interface IProductDao {
	public boolean addProductDetails(Product prod) throws ProductException;
	public Product getProductDetails(int productId)  throws ProductException;
	public boolean getAllProductDetails()  throws ProductException;
}

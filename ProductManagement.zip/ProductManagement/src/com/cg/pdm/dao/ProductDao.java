package com.cg.pdm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.pdm.bean.Product;
import com.cg.pdm.exception.ProductException;
import com.cg.pdm.util.DBUtil;

public class ProductDao implements IProductDao{

	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;
	public ProductDao() {
		
		
	}

	@Override
	public boolean addProductDetails(Product prod) throws ProductException {
		try(Connection connection = DBUtil.obtainConnection();PreparedStatement pstInsert = connection
				.prepareStatement(IQueryMapper.INSERT_QUERY))
				{
			pstInsert.setInt(1, prod.getProductId());
			pstInsert.setString(2, prod.getProductName());
			pstInsert.setInt(3, prod.getQuantity());
			pstInsert.setDouble(4, prod.getCost());
			int count = pstInsert.executeUpdate();
			if(count>0)
				return true;
			else
				return false;
				}
		
		catch(SQLException exp)
		{
			throw new ProductException("CAnnot Add");
		}
		
	}
	public Product mapRow(ResultSet row) throws ProductException {
		Product prod= new Product();
		try {
			prod.setProductId(row.getInt("productId"));
			prod.setProductName(row.getString("productName"));
			prod.setQuantity(row.getInt("quantity"));
			prod.setCost(row.getDouble("cost"));
					} catch (SQLException exp) {
			
			throw new ProductException("Failed to retrieve data!");
		}
		return prod;
	}
	@Override
	public Product getProductDetails(int productId) throws ProductException {
		Product prod = null;
		try (Connection con =DBUtil.obtainConnection();
				PreparedStatement pstSelectById = con
						.prepareStatement(IQueryMapper.SELECT_PROD_BY_ID_QRY)) {
			pstSelectById.setInt(1, productId);
			ResultSet result = pstSelectById.executeQuery();
			if (result.next()) {
				prod = (mapRow(result));
			}

		} catch (SQLException exp) {
			throw new ProductException("Failed to retieve");
		}
		return prod;
	}

	@Override
	public boolean getAllProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return false;
	}

}

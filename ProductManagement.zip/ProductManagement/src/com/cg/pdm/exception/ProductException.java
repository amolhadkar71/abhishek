package com.cg.pdm.exception;

public class ProductException extends Exception {

	public ProductException(String message) {
		super(message);
	}

}

package com.cg.pdm.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.cg.pdm.exception.ProductException;

public class DBUtil {
	static Connection connection;

	public static Connection obtainConnection() throws ProductException {
		try {
			InitialContext context = new InitialContext();
			DataSource source = (DataSource) context
					.lookup("java:/OracleDS");
			connection = source.getConnection();
		} catch (NamingException e) {
			throw new ProductException("Error while creating datascource::"
					+ e.getMessage());
		} catch (SQLException e) {
			throw new ProductException("Error while obtaining connection::"
					+ e.getMessage());
		}
		return connection;
	}
}
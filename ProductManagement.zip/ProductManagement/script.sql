CREATE TABLE PRODUCT(
productId NUMBER PRIMARY KEY,
productName VARCHAR2(20),
productQuantity NUMBER,
productCost	binary_double
);